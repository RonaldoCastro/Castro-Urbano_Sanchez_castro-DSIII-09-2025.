import { supabase } from './supabaseClient'

async function probarConexion() {
  const { data, error } = await supabase.from('productos').select('*')
  if (error) {
    console.error('❌ Error al conectar con Supabase:', error.message)
  } else {
    console.log('✅ Conexión exitosa. Datos:', data)
  }
}

probarConexion()