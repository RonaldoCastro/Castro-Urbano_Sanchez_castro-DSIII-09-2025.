import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL='https://mromlrvnwpftvzalsemw.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1yb21scnZud3BmdHZ6YWxzZW13Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk5NDkzNjgsImV4cCI6MjA3NTUyNTM2OH0.9ozSluwrR6SgRjzLV-oWTBguXp__eiopqakCpH2DgtI';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);